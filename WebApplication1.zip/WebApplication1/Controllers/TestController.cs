﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class TestController : Controller
    {
        //private WEBATTENDANCEEntities db = new WEBATTENDANCEEntities();
        //// GET: User  
        //public ActionResult Test()
        //{
        //     List<class1> list = new List<class1>();
        //    var query = db.DIEMDANHs.GroupBy(x => x.MASINHVIEN).Select(g => new { MASINHVIEN = g.Key, count = g.Count() });

        //    foreach (var item in query)
        //    {
        //        item.
        //    }
        //    return View();
        //}



    }
}