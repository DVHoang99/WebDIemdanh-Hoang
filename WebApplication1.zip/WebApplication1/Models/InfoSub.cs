﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class InfoSub
    {
        public string TenSv { get; set; }
        public string MaSv { get; set; }
       
    }
}