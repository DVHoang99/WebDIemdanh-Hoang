﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Teacher
    {
        public string ID { get; set; }
        public string TEN { get; set; }
        public string BANGCAP  { get; set; }
        public string CHUCVU { get; set; }
        public int MADONVI { get; set; }
        public string DONVI { get; set; }

    }
}