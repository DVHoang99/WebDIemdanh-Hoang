﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class CheckIn
    {
        public string MASINHVIEN { get; set; }

        public string TENSINHVIEN { get; set; }
        public string NGAYDIENDANH1 { get; set; }
        public string NGAYDIENDANH2 { get; set; }
        public string NGAYDIENDANH3 { get; set; }
        public string NGAYDIENDANH4 { get; set; }
        public string NGAYDIENDANH5{get;set;}

        public int SoBuoiDiemDanh { get; set; }
    }
}