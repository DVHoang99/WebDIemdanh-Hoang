﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class class1
    {
        public class1(string mASINHVIEN, int count)
        {
            MASINHVIEN = mASINHVIEN;
            Count = count;
        }

        public string MASINHVIEN { get; }
        public int Count { get; }
        string ten { get; set; }
        string ngay1 { get; set; }
    }
}